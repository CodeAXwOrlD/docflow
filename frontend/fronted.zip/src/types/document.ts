export type JobStatus = 
  | "queued" 
  | "processing" 
  | "completed" 
  | "failed" 
  | "finalized" 
  | "cancelled";

export type PipelineStage = 
  | "job_started"
  | "document_received"
  | "document_parsing_started"
  | "document_parsing_completed"
  | "field_extraction_started"
  | "field_extraction_completed"
  | "storing_result"
  | "job_completed"
  | "job_failed";

export interface DocumentItem {
  id: string;
  filename: string;
  original_filename: string;
  file_size: number;
  file_type: string;
  mime_type?: string;
  status: JobStatus;
  celery_task_id?: string | null;
  progress: number;
  current_stage?: PipelineStage | string | null;
  error_message?: string | null;
  retry_count: number;
  extracted_data?: Record<string, unknown> | null;
  reviewed_data?: Record<string, unknown> | null;
  is_reviewed: boolean;
  created_at: string;
  updated_at: string;
  completed_at?: string | null;
  is_synthetic?: boolean;
}

export interface DocumentListResponse {
  items: DocumentItem[];
  total: number;
  page: number;
  page_size: number;
}

export interface ProgressEvent {
  job_id: string;
  event: string;
  progress: number;
  message: string;
  data?: Record<string, unknown>;
}

export interface Stats {
  [key: string]: number | undefined;
  queued?: number;
  processing?: number;
  completed?: number;
  failed?: number;
  finalized?: number;
}

export interface ListDocumentsParams {
  page?: number;
  page_size?: number;
  status?: string;
  search?: string;
  sort_by?: string;
  sort_order?: "asc" | "desc" | string;
}

export type AppMode = "demo" | "live";
export type BackendHealth = "healthy" | "sleeping" | "offline" | "checking";
