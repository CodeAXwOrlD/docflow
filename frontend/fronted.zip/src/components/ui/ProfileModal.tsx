import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  User, Key, HardDrive, X, Copy, Check, CheckCircle2, ExternalLink, Shield
} from "lucide-react";
import toast from "react-hot-toast";

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function ProfileModal({ isOpen, onClose }: ProfileModalProps) {
  const [copiedKey, setCopiedKey] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText("df_live_4f89b1c78e90a21f7c324901");
    setCopiedKey(true);
    toast.success("API key copied");
    setTimeout(() => setCopiedKey(false), 2500);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.97, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.97, y: 8 }}
            transition={{ type: "spring", stiffness: 400, damping: 30 }}
            className="relative w-full max-w-md rounded-2xl bg-[#0b1123] border border-white/[0.08] p-6 shadow-2xl"
          >
            {/* Close */}
            <button
              onClick={onClose}
              className="absolute top-4 right-4 w-8 h-8 rounded-lg border border-white/[0.07] bg-white/[0.03] hover:bg-white/[0.07] flex items-center justify-center text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            {/* User header */}
            <div className="flex items-center gap-4 mb-6">
              <div className="relative">
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-cyan-400 to-blue-600 flex items-center justify-center font-bold text-lg text-white">
                  AM
                </div>
                <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 border-2 border-[#0b1123] flex items-center justify-center">
                  <Check className="w-2.5 h-2.5 text-black stroke-[3]" />
                </div>
              </div>

              <div>
                <h3 className="text-base font-semibold text-white">Alex Morgan</h3>
                <p className="text-xs text-slate-500 font-mono mt-0.5">lead.architect@docflow.internal</p>
                <div className="text-[11px] text-slate-400 mt-1">DocFlow member</div>
              </div>
            </div>

            {/* Storage & workers */}
            <div className="grid grid-cols-2 gap-3 mb-4">
              <div className="rounded-xl bg-white/[0.03] border border-white/[0.07] p-3.5">
                <div className="flex items-center justify-between text-xs text-slate-400 mb-2.5">
                  <span className="flex items-center gap-1.5">
                    <HardDrive className="w-3 h-3 text-slate-500" />
                    Storage
                  </span>
                  <span className="text-slate-300 font-mono">4.8%</span>
                </div>
                <div className="w-full h-1.5 rounded-full bg-white/[0.07] overflow-hidden">
                  <div className="h-full rounded-full bg-cyan-500" style={{ width: "4.8%" }} />
                </div>
                <div className="text-[10px] text-slate-600 font-mono mt-2">2.4 GB / 50 GB</div>
              </div>

              <div className="rounded-xl bg-white/[0.03] border border-white/[0.07] p-3.5">
                <div className="flex items-center justify-between text-xs text-slate-400 mb-2.5">
                  <span className="flex items-center gap-1.5">
                    <User className="w-3 h-3 text-slate-500" />
                    Workers
                  </span>
                  <span className="text-emerald-400 font-mono text-[11px]">healthy</span>
                </div>
                <div className="w-full h-1.5 rounded-full bg-white/[0.07] overflow-hidden">
                  <div className="h-full rounded-full bg-emerald-500" style={{ width: "25%" }} />
                </div>
                <div className="text-[10px] text-slate-600 font-mono mt-2">2 worker processes</div>
              </div>
            </div>

            {/* API key */}
            <div className="rounded-xl bg-white/[0.03] border border-white/[0.07] p-3.5 mb-5">
              <div className="flex items-center gap-2 text-xs font-medium text-slate-300 mb-2.5">
                <Key className="w-3 h-3 text-amber-400" />
                API Key
              </div>
              <div className="flex items-center gap-2">
                <code className="flex-1 px-2.5 py-1.5 rounded-lg bg-black/40 border border-white/[0.07] text-xs font-mono text-slate-400 select-all truncate">
                  df_live_4f89b1c78e90a21f7c324901
                </code>
                <button
                  onClick={handleCopy}
                  className="px-2.5 py-1.5 rounded-lg border border-white/[0.07] bg-white/[0.04] hover:bg-white/[0.08] text-xs font-medium text-white flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  {copiedKey ? (
                    <><CheckCircle2 className="w-3 h-3 text-emerald-400" /><span>Copied</span></>
                  ) : (
                    <><Copy className="w-3 h-3" /><span>Copy</span></>
                  )}
                </button>
              </div>
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between text-[11px] text-slate-500">
              <div className="flex items-center gap-1.5">
                <Shield className="w-3 h-3" />
                CORS verified
              </div>
              <a
                href="http://localhost:8000/docs"
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-1 text-cyan-500 hover:text-cyan-400 transition-colors font-medium"
              >
                API docs <ExternalLink className="w-2.5 h-2.5" />
              </a>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
