import React, { useState } from "react";
import {
  FileCode,
  Table,
  CheckCircle2,
  Edit3,
  Save,
  RotateCcw,
  Sparkles,
  Layers,
  AlertCircle,
  Copy,
  Check,
} from "lucide-react";
import toast from "react-hot-toast";

interface SchemaInspectorProps {
  extractedData?: Record<string, unknown> | null;
  reviewedData?: Record<string, unknown> | null;
  isReviewed: boolean;
  status: string;
  onSaveReview: (updatedData: Record<string, unknown>) => Promise<void>;
  onFinalize: () => Promise<void>;
  isFinalizing: boolean;
}

export default function SchemaInspector({
  extractedData,
  reviewedData,
  isReviewed,
  status,
  onSaveReview,
  onFinalize,
  isFinalizing,
}: SchemaInspectorProps) {
  const [activeTab, setActiveTab] = useState<"fields" | "json">("fields");
  const [isEditing, setIsEditing] = useState(false);
  const [copied, setCopied] = useState(false);

  // Initialize editable fields
  const currentData = reviewedData || extractedData || {};
  const [editedFields, setEditedFields] = useState<Record<string, string>>(() => {
    const initial: Record<string, string> = {};
    Object.entries(currentData).forEach(([k, v]) => {
      initial[k] = typeof v === "object" ? JSON.stringify(v, null, 2) : String(v ?? "");
    });
    return initial;
  });
  const [isSaving, setIsSaving] = useState(false);

  const handleCopyJson = () => {
    const jsonStr = JSON.stringify(currentData, null, 2);
    navigator.clipboard.writeText(jsonStr);
    setCopied(true);
    toast.success("Schema copied to clipboard");
    setTimeout(() => setCopied(false), 2000);
  };

  const handleFieldChange = (key: string, value: string) => {
    setEditedFields((prev) => ({ ...prev, [key]: value }));
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const parsedPayload: Record<string, unknown> = {};
      for (const [key, valStr] of Object.entries(editedFields)) {
        if (!key.trim()) continue;
        const trimmed = valStr.trim();
        // Check if string is a number, boolean, or valid JSON object/array
        if (trimmed === "true") parsedPayload[key] = true;
        else if (trimmed === "false") parsedPayload[key] = false;
        else if (trimmed !== "" && !isNaN(Number(trimmed)) && !trimmed.startsWith("0x")) {
          parsedPayload[key] = Number(trimmed);
        } else if (
          (trimmed.startsWith("{") && trimmed.endsWith("}")) ||
          (trimmed.startsWith("[") && trimmed.endsWith("]"))
        ) {
          try {
            parsedPayload[key] = JSON.parse(trimmed);
          } catch {
            parsedPayload[key] = trimmed;
          }
        } else {
          parsedPayload[key] = trimmed;
        }
      }

      await onSaveReview(parsedPayload);
      setIsEditing(false);
      toast.success("Changes saved");
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Failed to save review";
      toast.error(msg);
    } finally {
      setIsSaving(false);
    }
  };

  const handleCancel = () => {
    const reset: Record<string, string> = {};
    Object.entries(currentData).forEach(([k, v]) => {
      reset[k] = typeof v === "object" ? JSON.stringify(v, null, 2) : String(v ?? "");
    });
    setEditedFields(reset);
    setIsEditing(false);
  };

  if (!extractedData && !reviewedData) {
    return (
      <div className="surface-card p-8 text-center space-y-3">
        <Layers className="w-8 h-8 text-slate-600 mx-auto" />
        <h4 className="text-sm font-medium text-slate-400">No data yet</h4>
        <p className="text-xs text-slate-600 max-w-sm mx-auto">
          Processing hasn&apos;t completed for this document. Extracted fields will appear here once done.
        </p>
      </div>
    );
  }

  return (
    <div className="surface-card overflow-hidden">
      {/* Header bar */}
      <div className="p-4 border-b border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white/[0.01]">
        <div className="flex items-center gap-3">
          <div className="segmented-track flex items-center">
            <button
              onClick={() => setActiveTab("fields")}
              className={`segmented-item flex items-center gap-1.5 ${
                activeTab === "fields" ? "segmented-item-active" : ""
              }`}
            >
              <Table className="w-3.5 h-3.5" />
              <span>Fields</span>
            </button>
            <button
              onClick={() => setActiveTab("json")}
              className={`segmented-item flex items-center gap-1.5 ${
                activeTab === "json" ? "segmented-item-active" : ""
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              <span>Raw JSON</span>
            </button>
          </div>

          {isReviewed && (
            <span className="flex items-center gap-1 text-[11px] font-medium text-violet-400 bg-violet-500/10 border border-violet-500/20 px-2 py-0.5 rounded-md">
              <CheckCircle2 className="w-3 h-3" />
              Reviewed by Human
            </span>
          )}
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {activeTab === "json" ? (
            <button
              onClick={handleCopyJson}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-300 hover:text-white bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? "Copied" : "Copy JSON"}</span>
            </button>
          ) : (
            <>
              {isEditing ? (
                <>
                  <button
                    onClick={handleCancel}
                    disabled={isSaving}
                    className="px-3 py-1.5 rounded-lg text-xs font-medium text-slate-400 hover:text-white transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSave}
                    disabled={isSaving}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-white text-slate-900 hover:bg-slate-100 transition-all shadow-sm disabled:opacity-50"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>{isSaving ? "Saving…" : "Save"}</span>
                  </button>
                </>
              ) : (
                <>
                  <button
                    onClick={() => setIsEditing(true)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-300 hover:text-white bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 transition-colors"
                  >
                    <Edit3 className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Edit Fields</span>
                  </button>

                  {status === "completed" && (
                    <button
                      onClick={onFinalize}
                      disabled={isFinalizing}
                      className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-violet-600 hover:bg-violet-500 text-white transition-all shadow-sm"
                      title="Lock and finalize verified document schema"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-violet-200" />
                      <span>{isFinalizing ? "Finalizing..." : "Finalize Schema"}</span>
                    </button>
                  )}
                </>
              )}
            </>
          )}
        </div>
      </div>

      {/* Content Area */}
      <div className="p-5">
        {activeTab === "json" ? (
          <div className="bg-[#050811] rounded-xl border border-white/5 p-4 overflow-x-auto max-h-[500px] custom-glass-scrollbar">
            <pre className="font-mono text-xs text-slate-300 leading-relaxed">
              {JSON.stringify(currentData, null, 2)}
            </pre>
          </div>
        ) : (
          <div className="space-y-3">
            {Object.keys(editedFields).length === 0 ? (
              <div className="text-center py-6 text-xs text-slate-500">No fields identified in schema.</div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {Object.entries(editedFields).map(([key, val]) => {
                  const isMultiline = val.includes("\n") || val.length > 60;
                  return (
                    <div
                      key={key}
                      className={`
                        p-3 rounded-xl border transition-colors
                        ${isMultiline ? "md:col-span-2" : ""}
                        ${
                          isEditing
                            ? "bg-white/[0.03] border-cyan-400/20 focus-within:border-cyan-400/50"
                            : "bg-white/[0.02] border-white/5"
                        }
                      `}
                    >
                      <label className="block text-[10px] font-mono uppercase tracking-wider text-slate-400 mb-1">
                        {key.replace(/_/g, " ")}
                      </label>

                      {isEditing ? (
                        isMultiline ? (
                          <textarea
                            rows={3}
                            value={val}
                            onChange={(e) => handleFieldChange(key, e.target.value)}
                            className="w-full bg-[#080d1e] border border-white/10 rounded-lg p-2 text-xs text-slate-200 focus:outline-none focus:ring-1 focus:ring-cyan-400 font-mono"
                          />
                        ) : (
                          <input
                            type="text"
                            value={val}
                            onChange={(e) => handleFieldChange(key, e.target.value)}
                            className="w-full bg-[#080d1e] border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:ring-1 focus:ring-cyan-400 font-mono"
                          />
                        )
                      ) : (
                        <div className="text-xs text-slate-200 break-words font-mono">
                          {typeof val === "object" ? JSON.stringify(val) : String(val)}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
