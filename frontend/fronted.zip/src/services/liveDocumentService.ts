import axios, { AxiosInstance } from "axios";
import {
  DocumentItem,
  DocumentListResponse,
  ListDocumentsParams,
  ProgressEvent,
  Stats,
} from "../types/document";

export class LiveDocumentService {
  private client: AxiosInstance;
  private baseUrl: string;

  constructor(apiUrl?: string) {
    this.baseUrl = (apiUrl || process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000").replace(/\/$/, "");
    this.client = axios.create({
      baseURL: `${this.baseUrl}/api/v1`,
      timeout: 25000,
    });
  }

  public getBaseUrl(): string {
    return this.baseUrl;
  }

  public async checkHealth(): Promise<boolean> {
    try {
      const res = await axios.get(`${this.baseUrl}/health`, { timeout: 4000 });
      return res.status === 200 && res.data?.status === "ok";
    } catch {
      return false;
    }
  }

  public async listDocuments(params: ListDocumentsParams = {}): Promise<DocumentListResponse> {
    const res = await this.client.get<DocumentListResponse>("/documents", { params });
    return res.data;
  }

  public async getDocument(id: string): Promise<DocumentItem> {
    const res = await this.client.get<DocumentItem>(`/documents/${id}`);
    return res.data;
  }

  public async updateReview(id: string, reviewedData: Record<string, unknown>): Promise<DocumentItem> {
    const res = await this.client.put<DocumentItem>(`/documents/${id}/review`, {
      reviewed_data: reviewedData,
    });
    return res.data;
  }

  public async finalizeDocument(id: string): Promise<DocumentItem> {
    const res = await this.client.post<DocumentItem>(`/documents/${id}/finalize`);
    return res.data;
  }

  public async retryDocument(id: string): Promise<DocumentItem> {
    const res = await this.client.post<DocumentItem>(`/documents/${id}/retry`);
    return res.data;
  }

  public async deleteDocument(id: string): Promise<void> {
    await this.client.delete(`/documents/${id}`);
  }

  public async uploadDocuments(files: File[]): Promise<DocumentItem[]> {
    const form = new FormData();
    files.forEach((f) => form.append("files", f));
    const res = await this.client.post<DocumentItem[]>("/upload", form);
    return res.data;
  }

  public async getStats(): Promise<Stats> {
    const res = await this.client.get<Stats>("/stats");
    return res.data;
  }

  public subscribeToProgress(
    docId: string,
    callback: (event: ProgressEvent) => void
  ): () => void {
    const url = `${this.baseUrl}/api/v1/documents/${docId}/stream`;
    let eventSource: EventSource | null = null;

    try {
      eventSource = new EventSource(url);
      eventSource.onmessage = (e) => {
        try {
          const parsed = JSON.parse(e.data);
          callback({
            job_id: docId,
            event: parsed.event || "progress",
            progress: parsed.progress ?? 0,
            message: parsed.message || "",
            data: parsed.data,
          });
        } catch {
          // Ignore keepalives
        }
      };

      eventSource.onerror = () => {
        eventSource?.close();
      };
    } catch {
      // EventSource failed to instantiate
    }

    return () => {
      eventSource?.close();
    };
  }

  public exportDocument(id: string, format: "json" | "csv"): void {
    if (typeof window !== "undefined") {
      const url = `${this.baseUrl}/api/v1/documents/${id}/export/${format}`;
      window.open(url, "_blank");
    }
  }
}

export const liveDocumentService = new LiveDocumentService();
