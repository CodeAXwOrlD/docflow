# DocFlow

> **Asynchronous Document Ingestion, Schema Extraction & Review Pipeline**  
> Decouples heavy file parsing from HTTP request lifecycles using distributed background workers, event streaming, and an interactive human-in-the-loop review interface.

[![CI Pipeline](https://github.com/CodeAXwOrlD/docflow/actions/workflows/ci.yml/badge.svg)](https://github.com/CodeAXwOrlD/docflow/actions)
![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)
![Python 3.11+](https://img.shields.io/badge/Python-3.11+-3776AB?logo=python&logoColor=white)
![Next.js 14](https://img.shields.io/badge/Next.js-14-000000?logo=nextdotjs&logoColor=white)
![FastAPI](https://img.shields.io/badge/FastAPI-0.104-009688?logo=fastapi&logoColor=white)
![PostgreSQL 15](https://img.shields.io/badge/PostgreSQL-15-4169E1?logo=postgresql&logoColor=white)
![Redis 7](https://img.shields.io/badge/Redis-7-DC382D?logo=redis&logoColor=white)
![Celery 5](https://img.shields.io/badge/Celery-5.3-37814A?logo=celery&logoColor=white)

---

## 📌 Problem & Design Objectives

Extracting structured data from heterogeneous documents (PDFs, Word documents, Excel sheets, CSVs) is computationally expensive, I/O intensive, and prone to format errors. Handling this synchronously inside web request handlers leads to:
1. **HTTP request timeouts** on large payloads or multi-page documents.
2. **Blocked UI threads**, degraded user experience, and lack of visibility into parsing progress.
3. **Cascading server crashes** when malformed or encrypted documents exhaust memory or CPU.

**DocFlow** addresses this with a resilient, decoupled architecture:
- File ingestion instantly returns a tracking ID and queues the work to a Redis broker.
- Asynchronous Celery workers process documents through a deterministic multi-stage pipeline.
- Telemetry events stream to the browser via Server-Sent Events (SSE) and Redis Pub/Sub.
- An interactive Review & Finalization studio allows reviewers to inspect, modify, validate, and lock extracted schemas before downstream integration.
- A **Zero-Cost Client-Side Demo Sandbox** allows instant portfolio evaluation even when free-tier cloud backends are asleep or offline.

---

## ⚡ Execution Modes: Demo Sandbox vs. Live Cluster

DocFlow is architected with a unified repository pattern (`DocumentRepository`) that cleanly separates client-side demo execution from distributed cluster execution without cluttering components with conditionals.

| Feature | 🌟 Demo Sandbox Mode (Default) | 🚀 Live Cluster Mode |
|---|---|---|
| **Target Audience** | Portfolio visitors, recruiters, client evaluations | Local development, staging, production |
| **Backend Requirement** | **None.** Runs 100% client-side in the browser | FastAPI, PostgreSQL, Redis, Celery |
| **Hosting Cost** | **$0.00 / month** (Static Vercel / GitHub Pages) | Free tier (Render / Railway) or self-hosted VPS |
| **Cold Starts** | Instant load with zero delay | ~50s spin-up time on sleeping free tier instances |
| **Sample Datasets** | Preloaded realistic invoices, MSA contracts, audit reports | User-uploaded files stored in PostgreSQL |
| **Pipeline State Machine** | Deterministic browser timer simulation | Real distributed Celery worker task execution |
| **State Persistence** | LocalStorage with graceful in-memory fallback | PostgreSQL 15 database tables |
| **File Transmission** | **Zero bytes** sent over the wire (private sandbox) | Multipart stream to `/api/v1/upload` |
| **Switching Modes** | 1-click toggle in the top header | 1-click toggle in the top header |

> 💡 **Honest Demo Transparency:** Demo Mode clearly labels all preloaded records as synthetic samples and never claims files were processed by remote cloud workers. If a live API is unreachable, the UI provides a one-click fallback to Demo Mode instead of failing silently or showing recurring error toasts.

---

## 🏗 System Architecture

```mermaid
graph TD
    classDef frontend fill:#0284c7,stroke:#0369a1,stroke-width:2px,color:#fff
    classDef backend fill:#0d9488,stroke:#0f766e,stroke-width:2px,color:#fff
    classDef worker fill:#d97706,stroke:#b45309,stroke-width:2px,color:#fff
    classDef storage fill:#4f46e5,stroke:#4338ca,stroke-width:2px,color:#fff

    User((Client / Reviewer))

    subgraph "Frontend Layer (Next.js 14)"
        UI["Web Interface (Pages Router)"]:::frontend
        Repo["DocumentRepository Facade"]:::frontend
        DemoSvc["DemoDocumentService (Client-Side)"]:::frontend
        LiveSvc["LiveDocumentService (Axios / SSE)"]:::frontend
        UI --> Repo
        Repo -->|Demo Mode| DemoSvc
        Repo -->|Live Mode| LiveSvc
    end

    User --> UI

    subgraph "Backend Cluster (FastAPI & Celery)"
        API["FastAPI REST Endpoints"]:::backend
        Redis["Redis 7 (Broker & Pub/Sub)"]:::storage
        Worker["Celery Worker Fleet"]:::worker
        Postgres[("PostgreSQL 15 (Metadata & JSONB)")]:::storage

        LiveSvc -->|Upload & Control| API
        LiveSvc -.->|SSE Stream| API
        API -->|Enqueue Task| Redis
        API -->|Metadata Record| Postgres
        Worker -->|Consume Task| Redis
        Worker -->|Progress Events| Redis
        Redis -.->|Broadcast Pub/Sub| API
        Worker -->|Persist JSON Schema| Postgres
    end
```

---

## 🔄 Document Processing Pipeline Stages

Each document progresses through an explicit, auditable state machine:

1. `job_started` (5%): Background worker claims task from Redis broker.
2. `document_received` (10%): File signature and magic bytes validated; payload buffered into memory/disk.
3. `document_parsing_started` (20%): Structural boundaries, paragraph layout, or tabular ranges identified.
4. `document_parsing_completed` (45%): Text stream and metadata extracted.
5. `field_extraction_started` (55%): Entity recognition, keyword frequency, and category mapping.
6. `field_extraction_completed` (80%): Schema normalized into structured JSON key-values.
7. `storing_result` (90%): Extracted payload committed to PostgreSQL `extracted_data` column.
8. `job_completed` (100%): Document marked as `completed` and unlocked for human review.

*In the event of an unreadable or encrypted document (e.g. password-protected PDF), the pipeline transitions cleanly to `job_failed` with explicit error diagnostics, and unlocks a one-click Retry action.*

---

## 🛠 Tech Stack

### Frontend
- **Framework:** Next.js 14 (Pages Router, Static Export compatible)
- **Language:** TypeScript 5
- **Styling:** Tailwind CSS, PostCSS
- **State & Icons:** React 18, Framer Motion, Lucide React
- **Notifications:** React Hot Toast (rate-limited, no flood loops)

### Backend
- **API Framework:** FastAPI 0.104, Uvicorn
- **Asynchronous ORM:** SQLAlchemy 2.0 (AsyncPG + Psycopg2)
- **Database Migrations:** Alembic 1.13+
- **Task Queue & Broker:** Celery 5.3 + Redis 7
- **Document Extractors:** PyPDF2, python-docx, openpyxl

---

## 🚀 Getting Started

### Option A — Full-Stack Docker Compose (Recommended)

Spins up the complete distributed cluster (PostgreSQL, Redis, FastAPI, Celery Worker, Celery Flower, and Next.js):

```bash
git clone https://github.com/CodeAXwOrlD/docflow.git
cd docflow

# Build and start all containers in detached mode
make up-d
```

| Service | Address | Description |
|---|---|---|
| **Frontend UI** | [http://localhost:3000](http://localhost:3000) | Document ingestion & control room |
| **Backend API** | [http://localhost:8000](http://localhost:8000) | REST API |
| **Swagger UI** | [http://localhost:8000/docs](http://localhost:8000/docs) | Interactive OpenAPI documentation |
| **Celery Flower** | [http://localhost:5555](http://localhost:5555) | Worker queue & task telemetry |

```bash
# View aggregated service logs
make logs

# Stop all containers
make down

# Stop and wipe database/redis volumes (clean reset)
make down-v
```

---

### Option B — Local Development (Without Docker)

#### Prerequisites
- **Python 3.11+**
- **Node.js 20+**
- Running **PostgreSQL 15** and **Redis 7** instances

#### 1. Setup Backend
```bash
cd backend
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Run database migrations
alembic upgrade head
```

Create `backend/.env`:
```env
DATABASE_URL=postgresql+asyncpg://docflow:docflow_secret@localhost:5432/docflow_db
SYNC_DATABASE_URL=postgresql://docflow:docflow_secret@localhost:5432/docflow_db
REDIS_URL=redis://localhost:6379/0
UPLOAD_DIR=./uploads
MAX_FILE_SIZE_MB=50
CORS_ORIGINS=http://localhost:3000,http://127.0.0.1:3000
ENVIRONMENT=development
```

#### 2. Setup Frontend
```bash
cd ../frontend
npm install
```

Create `frontend/.env.local`:
```env
NEXT_PUBLIC_API_URL=http://localhost:8000
NEXT_PUBLIC_DEMO_MODE=true
```

#### 3. Start Services (3 Terminals)
- **Terminal 1 (API):** `make dev-backend`
- **Terminal 2 (Worker):** `make dev-worker`
- **Terminal 3 (UI):** `make dev-frontend`

---

## ☁️ Zero-Cost Hosting Guide

Deploy a live public portfolio version with **$0 infrastructure spend**:

### 1. Frontend: Vercel (Hobby Tier — $0/mo)
1. Push this repository to GitHub.
2. Import the project into Vercel and set the Root Directory to `frontend`.
3. Configure Environment Variables:
   - `NEXT_PUBLIC_DEMO_MODE`: `true`
   - `NEXT_PUBLIC_API_URL`: `https://your-backend.onrender.com` (optional)
4. Deploy. Vercel automatically compiles the static Next.js build. Portfolio visitors get an instant, interactive experience with zero cold starts.

### 2. Backend (Optional): Render (Free Tier — $0/mo)
1. Create a **Web Service** on Render pointing to the `backend/` directory using the provided `backend/Dockerfile`.
2. Attach a free PostgreSQL database and free Redis instance.
3. Configure environment variables matching `backend/.env.example`.
4. *Render free web services spin down after 15 minutes of inactivity. When asleep, DocFlow frontend displays a polite status badge and continues seamlessly in Demo Sandbox Mode.*

---

## 🧪 Testing & CI Pipeline

DocFlow includes automated unit, integration, linting, and build verification:

```bash
# Run backend test suite (18 unit and integration tests)
make test

# Run frontend linting (ESLint + Core Web Vitals)
make lint-frontend

# Verify production Next.js build
make build-frontend

# Run all checks locally
make test-all
```

### GitHub Actions CI
Every commit and pull request triggers `.github/workflows/ci.yml`:
1. **Backend Job:** Tests Python 3.11 environment, executes `pytest backend/tests/ -v`, and tests offline SQL generation for Alembic migrations.
2. **Frontend Job:** Sets up Node.js 20, verifies `npm run lint`, and validates `npm run build`.

---

## 🔒 Security & Operational Limitations

- **File Validation:** Ingestion strictly enforces maximum file size caps (50MB), extension allowlists, and magic byte signature verification (e.g. `%PDF-` header validation).
- **Orphan Cleanup:** Files created prior to failed database transactions or disconnected Redis queues are automatically cleaned up from disk.
- **Sort Allowlisting:** Database queries validate `sort_by` and `sort_order` against explicit column allowlists to prevent injection or internal model attribute disclosure.
- **Worker Isolation:** Database engines are lazily managed per worker process (`@worker_process_init`) to avoid connection pool cross-talk across prefork children.
- **Current Limitations:**
  - OCR extraction on scanned/image-only PDFs requires external Tesseract / Vision API integration (scanned PDFs without text streams cleanly fail with explicit OCR diagnostics).
  - Multi-tenant authentication (OAuth/JWT) is currently unconfigured; the platform operates in single-team cluster mode.

---

## 📄 License

This project is licensed under the **MIT License**. See the [LICENSE](LICENSE) file for details.
